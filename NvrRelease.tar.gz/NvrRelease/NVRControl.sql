/*
Navicat MySQL Data Transfer

Source Server         : 172.23.142.155
Source Server Version : 50525
Source Host           : 172.23.142.155:3306
Source Database       : NVRControl

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2017-06-08 14:34:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `downLoad`
-- ----------------------------
DROP TABLE IF EXISTS `downLoad`;
CREATE TABLE `downLoad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cinemaName` varchar(255) DEFAULT NULL,
  `HallNo` varchar(255) DEFAULT NULL,
  `IPCPosotion` int(11) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `startTime` varchar(255) DEFAULT NULL,
  `endTime` varchar(255) DEFAULT NULL,
  `ipcIp` varchar(255) DEFAULT NULL,
  `DownLoadID` bigint(11) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `mp4filename` varchar(255) DEFAULT NULL,
  `covertstate` int(11) DEFAULT NULL,
  `avifilename` varchar(255) DEFAULT NULL,
  `loginHandle` bigint(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of downLoad
-- ----------------------------

-- ----------------------------
-- Table structure for `ipc`
-- ----------------------------
DROP TABLE IF EXISTS `ipc`;
CREATE TABLE `ipc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cinemaName` varchar(255) DEFAULT NULL,
  `HallNo` int(11) DEFAULT NULL,
  `ipcPosition` int(11) DEFAULT NULL,
  `frameRate` int(11) DEFAULT NULL,
  `CBR` int(11) DEFAULT NULL,
  `resolvingRate` varchar(255) DEFAULT NULL,
  `decodeMode` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mode` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  `channelID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ipc
-- ----------------------------
INSERT INTO `ipc` VALUES ('1', '', '1', '1', '0', '0', '', '', '', '', '', '', '', '2');
INSERT INTO `ipc` VALUES ('2', '', '2', '1', '0', '0', '', '', '', '', '', '', '', '1');
INSERT INTO `ipc` VALUES ('3', '', '3', '1', '0', '0', '', '', '', '', '', '', '', '0');
INSERT INTO `ipc` VALUES ('4', '', '4', '1', '0', '0', '', '', '', '', '', '', '', '3');

-- ----------------------------
-- Table structure for `nvr`
-- ----------------------------
DROP TABLE IF EXISTS `nvr`;
CREATE TABLE `nvr` (
  `id` int(11) NOT NULL,
  `cinemaName` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `ipcNo` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `port` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of nvr
-- ----------------------------
